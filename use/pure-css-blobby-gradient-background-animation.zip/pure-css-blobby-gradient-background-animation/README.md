# Pure CSS Blobby Gradient Background Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ciprian/pen/JjQXdZO](https://codepen.io/ciprian/pen/JjQXdZO).

