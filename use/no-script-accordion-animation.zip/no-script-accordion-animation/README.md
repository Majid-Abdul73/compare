# No script accordion animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/jakob-e/pen/vYMEapr](https://codepen.io/jakob-e/pen/vYMEapr).

